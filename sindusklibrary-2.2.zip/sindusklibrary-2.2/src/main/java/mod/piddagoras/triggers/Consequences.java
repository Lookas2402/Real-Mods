package mod.piddagoras.triggers;

import java.util.Map;

public abstract class Consequences {
	public abstract void call(Map<String, Object> data);
}
