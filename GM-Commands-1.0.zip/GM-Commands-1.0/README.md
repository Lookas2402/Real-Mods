# GM Commands

**Adds commands for GM's to be more productive.**

**Commands include:**

**#addaff <player> <skill>**
- Add an affinity to a player. Note - Skill name must be capitalized.

**#addsleep <player>**
- Fill sleep bonus of chosen player.

**#coffers**
- Show current coffer value.

**#fillup <player>**
- Fill a players food, water, health, CCFP, and nutrition bars.

**#goto <deed|player>**
- Teleport yourself to any player or village (choose either a deed or a player).

**#massrefresh**
- Fill food, water, health, CCFP, and nutrition bars of all current players.

**#moveplayer <player>**
- Summon player to you.

**#sendhome <player>**
- Send a player to their home deed.

**#resettraders**
- Reset items (not coin) on all traders.
