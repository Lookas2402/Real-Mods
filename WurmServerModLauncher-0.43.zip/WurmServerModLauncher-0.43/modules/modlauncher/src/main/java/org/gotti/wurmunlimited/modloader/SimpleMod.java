package org.gotti.wurmunlimited.modloader;

import org.gotti.wurmunlimited.modloader.interfaces.WurmServerMod;

public class SimpleMod implements WurmServerMod {

}
