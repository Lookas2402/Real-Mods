package org.gotti.wurmunlimited.modsupport.creatures;

public interface TraitsSetter {
	void setTraitBit(int i, boolean b);
}
