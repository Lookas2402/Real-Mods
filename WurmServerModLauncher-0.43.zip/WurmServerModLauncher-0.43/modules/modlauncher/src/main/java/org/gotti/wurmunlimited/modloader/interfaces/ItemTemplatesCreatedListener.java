package org.gotti.wurmunlimited.modloader.interfaces;

public interface ItemTemplatesCreatedListener {

	void onItemTemplatesCreated();
}
