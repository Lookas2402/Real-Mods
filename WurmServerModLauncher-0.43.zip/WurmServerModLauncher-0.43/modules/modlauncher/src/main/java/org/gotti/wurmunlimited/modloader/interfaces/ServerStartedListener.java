package org.gotti.wurmunlimited.modloader.interfaces;

public interface ServerStartedListener {

	void onServerStarted();

}
