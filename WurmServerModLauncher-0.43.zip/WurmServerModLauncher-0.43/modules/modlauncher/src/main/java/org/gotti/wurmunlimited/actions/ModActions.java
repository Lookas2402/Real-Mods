package org.gotti.wurmunlimited.actions;

@Deprecated
public class ModActions extends org.gotti.wurmunlimited.modsupport.actions.ModActions {

}
