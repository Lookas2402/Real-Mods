package org.gotti.wurmunlimited.modloader.interfaces;

/**
 * Compatibility interface
 */
@Deprecated
public interface WurmMod extends WurmServerMod {

}
