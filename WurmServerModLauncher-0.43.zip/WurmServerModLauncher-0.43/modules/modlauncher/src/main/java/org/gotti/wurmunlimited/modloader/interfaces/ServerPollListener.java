package org.gotti.wurmunlimited.modloader.interfaces;

public interface ServerPollListener {
	
	public void onServerPoll();

}
