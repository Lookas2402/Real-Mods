package com.wurmonline.server.combat;

@Deprecated
public interface ArmourTypes {
	public static final int ARMOUR_LEATHER = 1;
	public static final int ARMOUR_STUDDED = 2;
	public static final int ARMOUR_CHAIN = 3;
	public static final int ARMOUR_PLATE = 4;
	public static final int ARMOUR_RING = 5;
	public static final int ARMOUR_CLOTH = 6;
	public static final int ARMOUR_SCALE = 7;
	public static final int ARMOUR_SPLINT = 8;
	public static final int ARMOUR_LEATHER_DRAGON = 9;
	public static final int ARMOUR_SCALE_DRAGON = 10;
	public static final int ARMOUR_NONE = -1;
}
