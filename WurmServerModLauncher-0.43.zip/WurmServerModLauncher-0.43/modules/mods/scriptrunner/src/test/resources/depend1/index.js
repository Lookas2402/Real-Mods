var actions = require("actions");
var depend2 = require("./depend2");

module.exports = { actions : actions, depend2 : depend2.depend2, depend1 : 'depend1' };