load('src/dist/scriptrunner/imports/actions.js');

function test() {
	return 'OK';
}