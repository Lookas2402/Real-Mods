function test(arg) {
	if (arg === 'test') {
		return 'OK';
	}
	return 'FAIL';
}