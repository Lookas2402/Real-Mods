# Treasure Chest Claim mod for Wurm Unlimited (Server)

Requires [Ago's Server Mod Launcher](https://github.com/ago1024/WurmServerModLauncher/releases) to run.

This mod is free software: you can redistribute it and/or modify it under the terms of the [GNU Lesser General Public License](http://www.gnu.org/licenses/lgpl-3.0.en.html) as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

See the [forum thread](http://forum.wurmonline.com/index.php?/topic/138254-/) for more details and my other mods.
