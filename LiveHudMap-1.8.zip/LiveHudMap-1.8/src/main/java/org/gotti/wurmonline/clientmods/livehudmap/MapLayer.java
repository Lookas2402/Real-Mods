package org.gotti.wurmonline.clientmods.livehudmap;

public enum MapLayer {
	
	SURFACE,
	
	CAVE

}
